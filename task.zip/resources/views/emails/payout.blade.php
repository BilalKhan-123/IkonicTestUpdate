
{{-- This is sample but functional email template page --}}
<h4>Dear, {{ $name }}</h4>

<h4>Domain, {{ $domain }}</h4>

<p>{{$body}}</p>



<p>Thank you!</p>


